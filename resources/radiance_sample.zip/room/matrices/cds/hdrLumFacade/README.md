An empty place holder for the path room\matrices\cds\hdrLumFacade
Additional notes maybe added later.