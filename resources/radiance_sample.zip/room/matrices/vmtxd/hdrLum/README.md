An empty place holder for the path room\matrices\vmtxd\hdrLum
Additional notes maybe added later.