An empty place holder for the path room\matrices
Additional notes maybe added later.