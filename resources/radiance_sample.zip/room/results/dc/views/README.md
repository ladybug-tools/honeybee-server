An empty place holder for the path room\results\dc\views
Additional notes maybe added later.