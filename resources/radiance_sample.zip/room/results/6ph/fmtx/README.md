An empty place holder for the path room\results\6ph\fmtx
Additional notes maybe added later.