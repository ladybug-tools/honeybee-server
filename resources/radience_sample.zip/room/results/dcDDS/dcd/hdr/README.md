An empty place holder for the path room\results\dcDDS\dcd\hdr
Additional notes maybe added later.