An empty place holder for the path room\results\dcDDS\dc
Additional notes maybe added later.