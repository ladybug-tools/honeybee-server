An empty place holder for the path room\results
Additional notes maybe added later.