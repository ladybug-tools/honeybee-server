An empty place holder for the path room\results\6ph\fmtxd\hdr
Additional notes maybe added later.