An empty place holder for the path room\results\dc\hdr
Additional notes maybe added later.