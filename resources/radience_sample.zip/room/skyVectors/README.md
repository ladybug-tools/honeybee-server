An empty place holder for the path room\skyVectors
Additional notes maybe added later.