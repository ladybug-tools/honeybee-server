An empty place holder for the path room\matrices\cds\hdrIllSpace
Additional notes maybe added later.